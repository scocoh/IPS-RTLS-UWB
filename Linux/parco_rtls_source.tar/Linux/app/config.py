MQTT_BROKER = "127.0.0.1"

DB_CONFIGS_ASYNC = {
    "maint": {
        "database": "ParcoRTLSMaint",
        "user": "parcoadmin",
        "password": "parcoMCSE04106!",
        "host": "192.168.210.231",
        "port": 5432
    },
    "data": {
        "database": "ParcoRTLSData",
        "user": "parcoadmin",
        "password": "parcoMCSE04106!",
        "host": "192.168.210.231",
        "port": 5432
    },
    "hist_r": {
        "database": "ParcoRTLSHistR",
        "user": "parcoadmin",
        "password": "parcoMCSE04106!",
        "host": "192.168.210.231",
        "port": 5432
    },
    "hist_p": {
        "database": "ParcoRTLSHistP",
        "user": "parcoadmin",
        "password": "parcoMCSE04106!",
        "host": "192.168.210.231",
        "port": 5432
    },
    "hist_o": {
        "database": "ParcoRTLSHistO",
        "user": "parcoadmin",
        "password": "parcoMCSE04106!",
        "host": "192.168.210.231",
        "port": 5432
    }
}